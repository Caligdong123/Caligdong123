# Youtube-clone
Youtube clone using html and css .one of my best work<br>
I made a classy YouTube Clone UI design Included my youtube videos 😂😂 in that clone.<br>
Demo : https://imtiyazshamim.github.io/Youtube-clone/
youtube : https://www.youtube.com/watch?v=f5KeGg_boEM
![](demo.png)
<br>
Follow me ⤵️
<br>
LinkedIn: https://www.linkedin.com/in/shamim-imtiyaz-11a3406b/
<br>
Instagram: https://www.instagram.com/imtiyaz_15/?hl=en
